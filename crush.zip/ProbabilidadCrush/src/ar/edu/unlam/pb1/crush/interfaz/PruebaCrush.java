package ar.edu.unlam.pb1.crush.interfaz;

import java.util.Scanner;

import ar.edu.unlam.pb1.crush.dominio.Calculadora;

public class PruebaCrush {
	
	static Scanner teclado = new Scanner (System.in);
	
	public static void main(String[] args) {
		
		Calculadora calculadoraDelAmor = new Calculadora();
		
		String tuCrush;
		String tuNombre; 
		
		do {

		System.out.println("Ingresa el nombre de tu crush: " );
		tuCrush = teclado.next();
		
		System.out.println("Ingresa tu nombre: " );
		tuNombre = teclado.next();
		
		System.out.println(tuCrush + " y " + tuNombre + " tienen " + calculadoraDelAmor.calcularCompatibilidad() + "% de compatibilidad");
		
	}while (tuCrush!=null && tuNombre!=null);
		
	}
}
