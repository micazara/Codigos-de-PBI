package ar.edu.unlam.pb1.crush.dominio;

public class Calculadora {

	public int calcularCompatibilidad() {
		int compatibilidad = (int)(Math.round(Math.random()*100));
		return compatibilidad;
		
	}

}
