package ar.edu.unlam.interfaz;

import java.util.Scanner;

import ar.edu.unlam.dominio.Carrera;
import ar.edu.unlam.dominio.Comision;
import ar.edu.unlam.dominio.Persona;
import ar.edu.unlam.dominio.Nota;

public class InstitucionEducativa {

	private static final int MENU_DOCENTE_INGRESAR_PERSONA = 1, MENU_DOCENTE_MOSTRAR_PERSONA_POR_DNI = 2,
			MENU_DOCENTE_RECUPERAR_NOTA_PERSONA = 3, MENU_DOCENTE_PERSONAS_PROMOCIONARON = 4,
			MENU_DOCENTE_PROMEDIO_NOTA_2_PERSONAS_CURSARON = 5, MENU_PERSONA_VER_INFORMACION_MATERIA = 1, SALIR = 9;
	private static final String MENSAJE_CARRERAS = "\n 1 - Para WEB\n 2 - Para MOBILE",
			NOMBRE_PRIMER_PARCIAL = "PrimerParcial", NOMBRE_SEGUNDO_PARCIAL = "SegundoParcial";

	private static Scanner teclado = new Scanner(System.in);

	public static void main(String[] args) {
		mostrarMensaje("Bienvenido a la comision turno M");
		
		int id = ingresarNumeroEntero("\nIngrese ID de la comision: ");
		String materia = ingresarTexto("\nIngrese el nombre de la materia: ");
		char turno = ingresarTurno();
		
		Comision turnoM = new Comision(id, materia, turno);

		boolean sesionIniciada = false;
		Integer dni = null;
		String contrasenia = "";
		Boolean esDocente = false;

		do {
			mostrarMensaje("\nIngrese DNI para iniciar sesion.");
			dni = teclado.nextInt();

			mostrarMensaje("\nIngrese contrasenia");
			contrasenia = teclado.next();

			mostrarMensaje("\nEs docente?");
			char letra = teclado.next().charAt(0);
			esDocente = letra == 'S' || letra == 's';

			sesionIniciada = turnoM.iniciarSesion(dni, contrasenia, esDocente);

			if (!sesionIniciada) {
				mostrarMensaje("\nDNI o contrasenia incorrectos.");
			} else {
				mostrarPantalla(turnoM, dni, esDocente);
				sesionIniciada = false;
			}

		} while (!sesionIniciada);

	}

	private static void mostrarPantalla(Comision turnoM, Integer dni, Boolean esDocente) {
		int opcion = 0;

		if (esDocente) {
			do {
				mostrarMenuDocente();

				opcion = teclado.nextInt();
				Persona persona = null;
				boolean exito = false;
				Carrera carrera;

				switch (opcion) {
				case MENU_DOCENTE_INGRESAR_PERSONA:

					Double valorNota = ingresarValorNota("\nIngrese valor de la nota 1: ");
					Nota primerParcial = new Nota(NOMBRE_PRIMER_PARCIAL, valorNota, true);

					valorNota = ingresarValorNota("\nIngrese valor de la nota 2: ");
					Nota segundoParcial = new Nota(NOMBRE_SEGUNDO_PARCIAL, valorNota, false);

					String nombre = ingresarTexto("\nIngrese el nombre: ");
					String apellido = ingresarTexto("\nIngrese el apellido: ");
					Integer dniPersona = ingresarNumeroEntero("\nIngrese el DNI: ");
					String pass = ingresarTexto("\nIngrese la contrasenia: ");
					carrera = ingresarCarrera();

					persona = new Persona(nombre, apellido, dniPersona, pass, carrera, primerParcial, segundoParcial);
					exito = turnoM.ingresarPersona(persona);

					if (exito) {
						mostrarMensaje("\nPersona ingresada correctamente!");
					} else {
						mostrarMensaje("\nNo fue posible ingresar la persona.");
					}
					break;
				case MENU_DOCENTE_MOSTRAR_PERSONA_POR_DNI:
					dni = ingresarNumeroEntero("\nIngrese DNI de la persona: ");
					persona = turnoM.buscarPorDni(dni);

					if (persona != null) {
						mostrarMensaje("\nPersona: " + persona.toString());
					} else {
						mostrarMensaje("\nPersona no encontrada.");
					}
					break;
				case MENU_DOCENTE_RECUPERAR_NOTA_PERSONA:
					mostrarMensaje("\nIngrese DNI de la persona: ");
					dni = teclado.nextInt();

					valorNota = ingresarValorNota("\nIngrese el valor de la nota: ");
					boolean esPrimerParcial = esPrimerParcial("\nEs primer parcial?");

					String nombreNota = NOMBRE_SEGUNDO_PARCIAL;

					if (esPrimerParcial) {
						nombreNota = NOMBRE_PRIMER_PARCIAL;
					}

					Nota nota = new Nota(nombreNota, valorNota, esPrimerParcial);

					exito = turnoM.recuperarNota(dni, nota);

					if (exito) {
						mostrarMensaje("\nNota recuperada correctamente!");
					} else {
						mostrarMensaje("\nNo fue posible recuperar la nota.");
					}
					break;
				case MENU_DOCENTE_PERSONAS_PROMOCIONARON:
					carrera = ingresarCarrera();
					Persona[] personasPromocion = turnoM.obtenerPersonasDeLaCarreraQuePromocionaron(carrera);
					mostrarPersonas(personasPromocion);
					break;
				case MENU_DOCENTE_PROMEDIO_NOTA_2_PERSONAS_CURSARON:
					Double promedio = turnoM.obtenerElPromedioDeNota2DeLasPersonasQueCursaron();
					mostrarMensaje(
							"\nEl promedio de segundo parcial de personas que cursaron es: " + Math.round(promedio));
					break;
				case SALIR:
					break;
				}

			} while (opcion != SALIR);

		} else {
			do {
				mostrarMenuPersona();
				opcion = teclado.nextInt();

				switch (opcion) {
				case MENU_PERSONA_VER_INFORMACION_MATERIA:
					Persona persona = turnoM.buscarPorDni(dni);
					
					if (persona != null) {
						mostrarMensaje("\nPersona: " + persona.toString());
					} else {
						mostrarMensaje("\nOoops, algo salio mal.");
					}
					break;
				case SALIR:
					break;

				}

			} while (opcion != SALIR);
		}

	}

	private static String ingresarTexto(String mensaje) {
		mostrarMensaje(mensaje);
		return teclado.next();
	}

	private static Integer ingresarNumeroEntero(String mensaje) {
		mostrarMensaje(mensaje);
		return teclado.nextInt();
	}

	private static char ingresarTurno() {
		char turno = Comision.TURNO_MANIANA;
		Integer opcion = 0;

		do {
			mostrarMensaje("\n1 - Para TM\n2 - Para TN");
			opcion = teclado.nextInt();
		} while (opcion < 1 || opcion > 2);

		if(opcion == 2) {
			turno = Comision.TURNO_NOCHE;
		}
		
		return turno;
	}

	public static Double ingresarValorNota(String mensaje) {
		Double valor = 0.0;
		do {
			mostrarMensaje(mensaje);
			valor = teclado.nextDouble();

		} while (valor < 1 || valor > 10);

		return valor;
	}

	private static boolean esPrimerParcial(String mensaje) {
		mostrarMensaje(mensaje);
		return teclado.nextBoolean();
	}

	private static Carrera ingresarCarrera() {
		int opcion = 0;
		do {
			mostrarMensaje(MENSAJE_CARRERAS);
			opcion = teclado.nextInt();

		} while (opcion < 1 || opcion > 2);

		return Carrera.values()[opcion - 1];
	}

	private static void mostrarMenuDocente() {
		mostrarMensaje("\nBienvenido al menu de docentes. ¿Que desea hacer?");
		mostrarMensaje("\n\n" + MENU_DOCENTE_INGRESAR_PERSONA + " - Para ingresar una persona.");
		mostrarMensaje("\n" + MENU_DOCENTE_MOSTRAR_PERSONA_POR_DNI + " - Para buscar una persona por DNI.");
		mostrarMensaje("\n" + MENU_DOCENTE_RECUPERAR_NOTA_PERSONA + " - Para recuperar la nota de una persona.");
		mostrarMensaje(
				"\n" + MENU_DOCENTE_PERSONAS_PROMOCIONARON + " - Para visualizar las personas que promocionaron.");
		mostrarMensaje("\n" + MENU_DOCENTE_PROMEDIO_NOTA_2_PERSONAS_CURSARON
				+ " - Para ver el promedio de la nota 2 de personas que cursaron.");
		mostrarMensaje("\n" + SALIR + " - Para salir.");
	}

	private static void mostrarMenuPersona() {
		mostrarMensaje("\nBienvenido al menu de personas. ¿Que desea hacer?");
		mostrarMensaje("\n\n" + MENU_PERSONA_VER_INFORMACION_MATERIA + " - Para ver su informacion de la materia.");
		mostrarMensaje("\n" + SALIR + " - Para salir.");
	}

	/**
	 * Muestra la informacion de las personas en un array
	 * 
	 * @param personas Personas que se mostraran
	 * 
	 *                 Debe proporcionar el codigo necesario para que funcione
	 *                 correctamente
	 * 
	 */
	public static void mostrarPersonas(Persona[] personas) {
		for (int i = 0; i < personas.length; i++) {
			if (personas[i] != null) {
				mostrarMensaje(personas[i].toString());
			}
		}
	}

	public static void mostrarMensaje(String mensaje) {
		System.out.println(mensaje);
	}

}
