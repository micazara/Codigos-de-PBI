package ar.edu.unlam.dominio;

public enum CondicionFinal {
	PROMOCIONA, CURSA, DESAPROBADO
}
