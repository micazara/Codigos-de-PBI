package ar.edu.unlam.dominio;

public class Persona {

	private static final Double NOTA_MINIMA_RECUPERACION = 6.0;
	private static final Double NOTA_MINIMA_PROMOCION = 7.0;
	private static final Double NOTA_MAXIMA_CURSADA = 6.0;
	private static final Double NOTA_MINIMA_CURSADA = 4.0;

	private String nombre;
	private String apellido;
	private Integer dni;
	private String contrasenia;
	private Carrera carrera;
	private Nota parcial1;
	private Nota parcial2;

	/**
	 * El constructor debe generar las condiciones necesaias para garantizar el
	 * correcto funcionamiento de la app
	 */
	public Persona(String nombre, String apellido, Integer dni, String contrasenia, Carrera carrera, Nota primerParcial,
			Nota segundoParcial) {
		this.nombre = nombre;
		this.apellido = apellido;
		this.dni = dni;
		this.contrasenia = contrasenia;
		this.carrera = carrera;
		this.parcial1 = primerParcial;
		this.parcial2 = segundoParcial;
	}

	/**
	 * Actualiza la nota del alumno a partir de una nota proporcionada.
	 * 
	 * @param notaARecuperar Nota para recuperar el parcial 1 o el parcial 2.
	 * @return true si fue posible actualizar la nota
	 * 
	 *         Debe proporcionar el codigo necesario para que funcione
	 *         correctamente.
	 * 
	 */
	public boolean recuperarNota(Nota notaARecuperar) {
		// La nota solo puede recuperarse si es menor o igual a 6
		boolean exito = false;

		if (notaARecuperar.isEsPrimerParcial()) {
			if (this.parcial1.getValor() <= NOTA_MINIMA_RECUPERACION) {
				this.parcial1 = notaARecuperar;
				exito = true;
			}
		} else {

			if (this.parcial2.getValor() <= NOTA_MINIMA_RECUPERACION) {
				this.parcial2 = notaARecuperar;
				exito = true;
			}
		}

		return exito;
	}

	/**
	 * Indica la condicion de la persona frente a la materia
	 * 
	 * Debe proporcionar el codigo necesario para que funcione correctamente
	 * 
	 * - Si tiene 1 parcial con nota inferior a 4 la condicion final es DESAPROBADO.
	 * - Si tiene las dos notas entre 4 y 6 (inclusive ambos), la condicion final es
	 * CURSA. - Si ambas notas son mayores o iguales a 7, la condicion final es
	 * PROMOCIONA.
	 * 
	 */
	public CondicionFinal obtenerCondicionFinal() {
		// Para cumplir con las condiciones antes descritas.
		CondicionFinal cf = null;
		
		if(this.esNotaDesaprobada(this.parcial1) || this.esNotaDesaprobada(this.parcial2)) {
			cf = CondicionFinal.DESAPROBADO;
		}

		if (this.esNotaDePromocion(this.parcial1) && this.esNotaDePromocion(this.parcial2)) {
			cf = CondicionFinal.PROMOCIONA;
		}

		if (this.esNotaDeCursada(this.parcial1) && this.esNotaDeCursada(this.parcial2)) {
			cf = CondicionFinal.CURSA;
		}

		return cf;
	}

	private boolean esNotaDePromocion(Nota nota) {
		return nota != null && nota.getValor() >= NOTA_MINIMA_PROMOCION;
	}

	private boolean esNotaDeCursada(Nota nota) {
		return nota != null && nota.getValor() >= NOTA_MINIMA_CURSADA && nota.getValor() <= NOTA_MAXIMA_CURSADA;
	}
	
	private boolean esNotaDesaprobada(Nota nota) {
		return nota != null && nota.getValor() < NOTA_MINIMA_CURSADA;
	}

	public String getNombre() {
		return nombre;
	}

	public void setNombre(String nombre) {
		this.nombre = nombre;
	}

	public String getApellido() {
		return apellido;
	}

	public void setApellido(String apellido) {
		this.apellido = apellido;
	}

	public Integer getDni() {
		return dni;
	}

	public void setDni(Integer dni) {
		this.dni = dni;
	}

	public String getContrasenia() {
		return contrasenia;
	}

	public void setContrasenia(String contrasenia) {
		this.contrasenia = contrasenia;
	}

	public Carrera getCarrera() {
		return carrera;
	}

	public void setCarrera(Carrera carrera) {
		this.carrera = carrera;
	}

	public Nota getParcial1() {
		return parcial1;
	}

	public void setParcial1(Nota parcial1) {
		this.parcial1 = parcial1;
	}

	public Nota getParcial2() {
		return parcial2;
	}

	public void setParcial2(Nota parcial2) {
		this.parcial2 = parcial2;
	}

	// Estaba bueno agregar la condicion final.
	@Override
	public String toString() {
		return "Persona [nombre=" + nombre + ", apellido=" + apellido + ", dni=" + dni + ", contrasenia=" + contrasenia
				+ ", carrera=" + carrera + ", parcial1=" + parcial1 + ", parcial2=" + parcial2 + ", Condicion final="
				+ this.obtenerCondicionFinal() + "]";
	}

}
