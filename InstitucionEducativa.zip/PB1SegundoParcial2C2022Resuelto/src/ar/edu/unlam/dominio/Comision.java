package ar.edu.unlam.dominio;

public class Comision {
	public static final char TURNO_MANIANA = 'M';
	public static final char TURNO_NOCHE = 'N';
	private static final int CANTIDAD_PERSONAS = 100;
	private static final Integer DNI_DOCENTE = 1234;
	private static final String CONTRASENIA = "asdf";

	private int id;
	private String materia;
	private char turno; // M -> Mañana | N -> Noche
	private Persona[] personas;
	private Integer dni;
	private String contrasenia;

	/**
	 * El constructor debe generar las condiciones necesaias para garantizar el
	 * correcto funcionamiento de la app
	 */
	public Comision(int id, String materia, char turno) {
		this.dni = DNI_DOCENTE;
		this.contrasenia = CONTRASENIA;
		this.personas = new Persona[CANTIDAD_PERSONAS];

		this.id = id;
		this.materia = materia;
		this.turno = turno;
	}

	/**
	 * Agrega una persona a la comision.
	 * 
	 * @param persona Persona que se agregara
	 * @return true en caso de exito
	 * 
	 *         Debe proporcionar el codigo necesario para que funcione correctamente
	 */
	public boolean ingresarPersona(Persona persona) {
		boolean ingresado = false;

		// TODO: validar que la persona no exista en la comision (por dni).
		if (!this.existePersonaEnComision(persona)) {

			int i = 0;
			while (i < this.personas.length && !ingresado) {

				if (this.personas[i] == null) {
					this.personas[i] = persona;
					ingresado = true;
				}
				i++;
			}

		}
		return ingresado;
	}

	/**
	 * Verifica si la persona que llega como parametro, existe en la comision
	 * 
	 * @param persona Persona que se validara
	 * @return true en caso de existir en la comision
	 * 
	 *         Debe proporcionar el codigo necesario para que funcione correctamente
	 * 
	 */
	private boolean existePersonaEnComision(Persona persona) {
		Persona buscada =this.buscarPorDni(persona.getDni());
		return buscada != null;
	}

	/**
	 * Devuelve una persona que debe ser encontrada por su DNI proporionado como
	 * parametro
	 * 
	 * @param dni DNI de la persona
	 * @return Persona Persona que aplica a la busqueda o null en caso de no
	 *         encontrarla.
	 * 
	 *         Debe proporcionar el codigo necesario para que funcione correctamente
	 * 
	 */
	public Persona buscarPorDni(Integer dni) {
		Persona persona = null;

		int i = 0;
		while (i < this.personas.length && persona == null) {
			if (this.personas[i] != null && this.personas[i].getDni().equals(dni)) {
				persona = this.personas[i];
			}

			i++;
		}

		return persona;
	}

	/**
	 * Inicia la sesion de una persona en la comision
	 * 
	 * @param dni         DNI de la persona
	 * @param contrasenia Contrasenia de la persona
	 * @param esDocente   Define si la persona es el docente
	 * @return true en caso de exito
	 * 
	 *         Debe proporcionar el codigo necesario para que funcione correctamente
	 */
	public boolean iniciarSesion(Integer dni, String contrasenia, Boolean esDocente) {
		boolean exito = false;

		if (esDocente) {
			exito = dni.equals(DNI_DOCENTE) && contrasenia.equals(CONTRASENIA);
		} else {
			Persona persona = this.buscarPorDni(dni);

			if (persona != null) {
				exito = persona.getContrasenia().equals(contrasenia);
			}
		}

		return exito;
	}

	/**
	 * Actualiza el valor de la Nota para la persona que cumple con el DNI pasado
	 * como parametro
	 * 
	 * @param dni  DNI de la persona
	 * @param nota Nota que se actualizará
	 * 
	 *             Debe proporcionar el codigo necesario para que funcione
	 *             correctamente
	 */
	public boolean recuperarNota(Integer dni, Nota nota) {
		Persona persona = this.buscarPorDni(dni);

		if (persona == null) {
			return false;
		}

		return persona.recuperarNota(nota);
	}

	/**
	 * Devuelve un array de personas que pertenecen a la carrera proporcionada como
	 * parametro y promocionaron la materia
	 * 
	 * @param carrera Carrera a la que pertenece la persona
	 * @return array de personas que pertenecen a la carrera
	 * 
	 *         Debe proporcionar el codigo necesario para que funcione correctamente
	 */
	public Persona[] obtenerPersonasDeLaCarreraQuePromocionaron(Carrera carrera) {
		// TODO: las personas devueltas deben estar ordenadas por DNI
		this.ordenarPersonasPorDni();

		Persona[] promocionaron = new Persona[CANTIDAD_PERSONAS];
		int indice = 0;

		for (int i = 0; i < this.personas.length; i++) {
			if (this.personas[i] != null && this.personas[i].getCarrera().equals(carrera)
					&& this.personas[i].obtenerCondicionFinal().equals(CondicionFinal.PROMOCIONA)) {
				promocionaron[indice++] = this.personas[i];
			}
		}

		return promocionaron;
	}

	/**
	 * Devuelve el calculo del promedio de la nota 2 de las personas en la comision
	 * 
	 * @return Double Promedio
	 * 
	 *         Debe proporcionar el codigo necesario para que funcione correctamente
	 */
	public Double obtenerElPromedioDeNota2DeLasPersonasQueCursaron() {
		Double acumulador = 0.0;
		int cantidadCursaron = 0;

		for (int i = 0; i < this.personas.length; i++) {

			// La mayoria no entendio que son los de condicion CURSA, los tome como bien sin aplicar el filtro.
			if (this.personas[i] != null && this.personas[i].obtenerCondicionFinal().equals(CondicionFinal.CURSA)) {

				acumulador += this.personas[i].getParcial2().getValor();
				cantidadCursaron++;
			}
		}

		return acumulador / cantidadCursaron;
	}

	/**
	 * Ordena las personas en la comision por DNI
	 * 
	 * Debe proporcionar el codigo necesario para que funcione correctamente
	 */
	private void ordenarPersonasPorDni() {
		// Cuando no aclara el orden es ascendente.
		Persona aux = null;
		for (int i = 1; i < this.personas.length; i++) {
			for (int j = 0; j < this.personas.length - 1; j++) {

				if (this.personas[j] != null && this.personas[j + 1] != null
						&& this.personas[j].getDni() > this.personas[j + 1].getDni()) {
					aux = this.personas[j];
					this.personas[j] = this.personas[j + 1];
					this.personas[j + 1] = aux;
				}
			}
		}
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getMateria() {
		return materia;
	}

	public void setMateria(String materia) {
		this.materia = materia;
	}

	public char getTurno() {
		return turno;
	}

	public void setTurno(char turno) {
		this.turno = turno;
	}

	public Persona[] getPersonas() {
		return personas;
	}

	public void setPersonas(Persona[] personas) {
		this.personas = personas;
	}

	public Integer getDni() {
		return dni;
	}

	public void setUsuario(Integer dni) {
		this.dni = dni;
	}

	public String getContrasenia() {
		return contrasenia;
	}

	public void setContrasenia(String contrasenia) {
		this.contrasenia = contrasenia;
	}

}
