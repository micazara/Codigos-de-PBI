package ar.edu.unlam.dominio;

public enum Carrera {
	WEB, MOBILE
}
