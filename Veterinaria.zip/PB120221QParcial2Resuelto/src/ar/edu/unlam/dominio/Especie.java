package ar.edu.unlam.dominio;

public enum Especie {
	PERRO, GATO, AVE
}
