package ar.edu.unlam.pb1.veri.interfaz;

import java.util.Scanner;

public class TestVerificacion {

	static Scanner teclado = new Scanner(System.in);

	public static void main(String[] args) {
		boolean sePudoVerificar = false;
		do {
			String contrasenia = ingresarContrasenia();
			// verificar si la contrasenia cumple con los requisitos
			sePudoVerificar = verificarContrasenia(contrasenia);
			notificarSiSePudoCrearLaContrasenia(sePudoVerificar);

		} while (!sePudoVerificar);
	}

	private static void notificarSiSePudoCrearLaContrasenia(boolean sePudoVerificar) {
		if (sePudoVerificar) {
			mostrarMensaje("La contrasenia se creo correctamente");
		} else {
			mostrarMensaje("La contrasenia no cumple con los requisitos. Intente nuevamente");
		}
	}

	private static boolean verificarContrasenia(String contrasenia) {
		boolean tieneMayus = false;
		boolean tieneMinuscula = false;
		boolean tieneNumero = false;
		boolean tieneCaracterEspecial = false;

		char c; // variable auxiliar

		if (contrasenia.length() >= 8) { // si la contrasenia tiene como minimo 8 caracteres
			for (int i = 0; i < contrasenia.length(); i++) {
				c = contrasenia.charAt(i); // recorrer caracter por caracter para verificar
				tieneMayus = verificarSiTieneMayus(tieneMayus, c);
				tieneMinuscula = verificarSiTieneMinuscula(tieneMinuscula, c);
				tieneNumero = verificarSiTieneNumero(tieneNumero, c);
				tieneCaracterEspecial = verificarSiTieneCaracterEspecial(tieneCaracterEspecial, c);
			}
			if (tieneMayus && tieneMinuscula && tieneNumero && tieneCaracterEspecial) {
				return true;
			} else {
				return false;
			}

		} else {
			return false;

		}

	}

	private static boolean verificarSiTieneCaracterEspecial(boolean tieneCaracterEspecial, char c) {
		if (c >= 33 && c < 64) {
			tieneCaracterEspecial = true;
		}
		return tieneCaracterEspecial;
	}

	private static boolean verificarSiTieneNumero(boolean tieneNumero, char c) {
		if (Character.isDigit(c)) {
			tieneNumero = true;
		}
		return tieneNumero;
	}

	private static boolean verificarSiTieneMinuscula(boolean tieneMinuscula, char c) {
		if (Character.isLowerCase(c)) {
			tieneMinuscula = true;
		}
		return tieneMinuscula;
	}

	private static boolean verificarSiTieneMayus(boolean tieneMayus, char c) {
		if (Character.isUpperCase(c)) {
			tieneMayus = true;
		}
		return tieneMayus;
	}

	private static String ingresarContrasenia() {
		// notificar requisitos
		mostrarMensaje("Ingrese la contrasenia: " + "\nLa misma debe tener los siguientes requisitos:"
				+ "\n\tMinimo 8 caracteres" + "\n\t1 o mas mayusculas" + "\n\t1 o mas minusculas" + "\n\t1 o mas numeros"
				+ "\n\t1 o mas caracteres especiales");

		// ingresar la contrasenia
		String contrasenia = teclado.next();
		return contrasenia;
	}

	private static void mostrarMensaje(String mensaje) {
		System.out.println(mensaje);

	}

}
